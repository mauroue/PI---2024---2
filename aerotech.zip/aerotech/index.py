from django.db import models
import site
site.addsitedir('/usr/local/lib/python3.x/site-packages')

class Tecnico(models.Model):
    nome = models.CharField(max_length=100)
    email = models.EmailField()
    # ... outros campos

class Servico(models.Model):
    tecnico = models.ForeignKey(Tecnico, on_delete=models.CASCADE)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)
    data_inicio = models.DateTimeField()
    # ... outros campos